
//when the user scroll over 800 px, it will show the back to top button
window.onscroll = function(){
  scrollFunction();
};
function scrollFunction(){
  let button = document.getElementById("back-to-top");
  if(document.body.scrollTop > 600 || document.documentElement.scrollTop > 600){
    button.style.display = "block";
  } else{
    button.style.display = "none";
  }
}
//when the user click on the button, it will go back to the top
document.getElementById("back-to-top").addEventListener('click', function(){
  document.body.scrollTop = 0; //apply to Safari
  document.documentElement.scrollTop = 0; // apply to Chrome, Firefox, IE, etc.
});
